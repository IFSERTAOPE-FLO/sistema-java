# SISTEMA PARA A CANTINA - IFBA _CAMPUS_ EUCLIDES DA CUNHA


## Ata de Reunião

| Data       | Local        |
| ---------- | ------------ |
| 12/05/2022 | IFBA - _CAMPUS_ EUCLIDES DA CUNHA|


### Participantes
* Antonio Carlos Borges de Souza;
* Antônio Leopoldo França Filho;
* Ítalo Ricardo de Andrade Silva;
* Kauê Andrade dos Santos;
* Ruth Oliveira Pereira.

### Objetivos
* Diminuir o tempo do aluno na fila;
* Automatizar pedidos;
* Diminuir a desordem da cantina.

### Tópicos Discutidos
* Como iniciar o programa;
* As funções de cada um;
* Como nosso projeto melhoraria a instituição.

### Ações a serem tomadas
| Ação                                      | Responsável  |
| ----------------------------------------- | ------------ |
| Criar cadastro para clientes              | @Kauê Andrade|
| Permitir o funcionário determina os itens | @Ítalo Ricardo|
| Permitir o funcionário determinar quantos unidades dos itens estão disponíveis| @Antônio Leopoldo|
| Permitir que os clientes realizem pedidos | @Antonio Carlos   |
| Permitir que clientes reservem o pedido| @Antonio Carlos   |
| Permitir o cliente fazer o pagamento do pedido| @Ruth Oliveira   |
| Criar plano mensal de pagamento| @Antônio Leopoldo   |
| Criar verificação de quantidade de fichas de acordo com o plano mensal| @Ítalo Ricardo  |
| Permitir os funcionários marcarem os pedidos como entregues| @Ruth Oliveira   |


### Informações Adicionais

* Alguma coisa
