# Nome do Projeto - #i(1..4)

# Retrospectiva

| Início da Iteração | Término da iteração |
| ------------------ | ------------------- |
| xx/xx/xxxx         | xx/xx/xxxx          |


### O que estava planejado
| Atividade                                                    | Atribuição                         |
| ------------------------------------------------------------ | ---------------------------------- |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@pessoa1`, `@pessoa2`, `@pessoa3` |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@todos`                           |

### O que foi feito
| Atividade                                                    | Atribuição                         |
| ------------------------------------------------------------ | ---------------------------------- |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@pessoa1`, `@pessoa2`, `@pessoa3` |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@todos`                           |

### O que não foi feito
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
> **Nota:** Levante o que não foi realizado e o seu respectivo impedimento.

### Planejado para próxima iteração
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! 

### Lições aprendidas
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!
* Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi!

> **Nota:** Levante o que foi aprendido nesta iteração, seja de carácter individual e/ou coletivo.