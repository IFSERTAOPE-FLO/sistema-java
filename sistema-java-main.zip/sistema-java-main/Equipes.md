# Equipes

## (1) Nome do Projeto: Controle de vendas

- Glendah Silva Costa (glendacosta432@gmail.com);
- Lauanda Jones Almeida da Silva (lauandajones32123@gmail.com);
- Luciane Eloiza Abreu de Oliveira (eloiza12abreeu@gmail.com);
- Mariane Barbosa Torres (torresmariane76@gmail.com);
- Vitória Dantas de Oliveira (vitoriadantasoliveira.vd@gmail.com) \*

Link do projeto: [Link]()

> Obs.: Projeto precisa ser melhor detalhado

## (2) Nome do Projeto: *Indefinido*

- Anailsa Santos Santos
- Gabriel Dias de Andrade
- Ítalo Carvalho Silva
- Karlla Tauany da Silva Rodrigues
- Lívia Beatriz dos Santos Bahia
- Luiziane França da Cruz

Link do projeto: [Link]()

> Obs.: São muitos temas. Precisa-se focar em um e fazê-lo bem feito! Falta os emails e a definição do líder. 
>
> Obs.2: Grupo com 6 componentes. *Máximo de 5 membros.*

## (3) Nome do Projeto: Sistema de Gerenciamento de uma Empresa

- Maria Eduarda Barboza Santos
- Maria Luíza Costa Andrade

Link do projeto: [Link]()

> Obs.: Projeto precisa ser melhor detalhado; Falta emails e a definição do líder.

## (4) Nome do Projeto: Cantina

- Helena Patrícia de Souza Silva (helena121280@gmail.com)
- Karolayne Silva Nascimento (karolnascicunha@gmail.com)
- Larissa Silva Nunes (la.nunes20@gmail.com)
- Julia Pereira de Andrade (juliaandrade645@gmail.com)
- Kalany de Sousa Santana ([soukalany@gmail.com](mailto:soukalany@gmail.com))

Link do projeto: [Link]()

> Obs.: Falta a definição do líder.
