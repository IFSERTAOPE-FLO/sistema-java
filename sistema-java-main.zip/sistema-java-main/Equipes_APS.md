# Equipes

## (1) Nome do Projeto: Estudando com questões

- Gustavo Silva Dantas
- Reinan Kauã Oliveira de Morais *
- Shirley Andrade Santana

Link do projeto: [Link](https://github.com/reinankaua/EstudandoComQuestoes)

## (2) Nome do Projeto: Farmácia

- Camila Marcos Varjão - 3°A
- Débora Dias de Almeida - 3° A
- Manoel Vinicius Silva Souza - 3° A
- Maria Luisa Marques Dantas - 3° A
- Sara Oliveira Silva Cardozo - 3°A *

Link do projeto: [Link](https://github.com/oliveiraSARA3/Farmacia)

## (3) Nome do Projeto: Clínica veterinária

- Bianca Pereira da Franca *
- Emanuela Santana Vieira
- Laiza Reis Severo

Link do projeto: [Link](https://github.com/Bianca-Franca/CLINICA-VETERINARIA#readme)

## (4) Nome do Projeto: Brasil Sem Frio

- Lara Beatriz Santos Calazans *
- Danielle Souza do Carmo
- Geovanna Barbosa Araújo
- Sarah Emanuelle Barreto dos Santos Souza
- Júlia Emylle Cavalcante Macêdo

Link do projeto: [Link](https://github.com/larafuracao/LP1-BrasilSemFrio-2021)

## (5) Nome do Projeto: Sistema da concessionária SCN

- Vinícius Alves;
- Dilma Stephane Carvalho;
- Gilsilvan Reis;
- Pedro Henrique Carmo;
- Josivânia;

Link do projeto: [Link](https://github.com/A1ves-V1nn1/APSConcessionaria3)

## (6) Nome do Projeto: **Planner Virtual**

- Douglas Caetano Brasil *
- Sabrina do Nascimento Santos
- Laiane dos Santos Oliveira
- Lorena Santos Paixão
- Victória Bispo dos Santos;

Link do projeto: [Link](https://github.com/Douglas3B/Planner-virtual)

## (7) Nome do Projeto: Policlínica fisioterapêutica

- Kaylane de Jesus Pereira
- Márcia Vitoria Silva Moura
- Pamella Andrade Souza
- Suzana da Silva Oliveira

Link do projeto: [Link](http://github.com/MarciaVitoria21/Policlinica-Fisioterapeutica)

## (8) Nome do Projeto: **Sistema de loja online de cosméticos**

- Maria Klara Nunes Martins de Oliveira

Link do projeto: [Link]()

> Não mandou o link do GitHUB

## (9) Nome do Projeto: Tá Marcado

- José Garcês da Silva Neto;
- Kauê Xavier Santos Moura;
- Mateus de Almeida Vieira;
- Michel Cardoso Macêdo Filho;
- Pedro Henrique Carvalho Lima Cabral

Link do projeto: [Link](https://github.com/Mavie0905/TaMarcado)

## (10) Nome do Projeto: ISPA

- Ana Fátima Cavalcante de Matos
- Camille Vitória Dias Costa
- Emanueli Gomes de Carvalho
- Isla Sena de França Cunha
- Isa Kaiane de Oliveira da Silva 

Link do projeto: [Link](https://github.com/IslaCunha/Projeto-ISPA)
