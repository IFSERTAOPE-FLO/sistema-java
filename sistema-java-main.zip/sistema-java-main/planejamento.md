# Nome do Projeto - #i(1..4)

# Planejamento

| Início da Iteração | Término da iteração |
| ------------------ | ------------------- |
| xx/xx/xxxx         | xx/xx/xxxx          |


### O que fazer na iteração #i

| Atividade                                                    | Atribuição                         |
| ------------------------------------------------------------ | ---------------------------------- |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@pessoa1`, `@pessoa2`, `@pessoa3` |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@todos`                           |

### O que foi feito até a iteração #i

| Atividade                                                    | Atribuição                         |
| ------------------------------------------------------------ | ---------------------------------- |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@pessoa1`, `@pessoa2`, `@pessoa3` |
| Mussum Ipsum, cacilds vidis litro abertis. Si num tem leite então bota uma pinga aí cumpadi! | `@todos`                           |
